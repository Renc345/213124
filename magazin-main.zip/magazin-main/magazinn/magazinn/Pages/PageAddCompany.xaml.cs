﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using magazinn.Classes;

namespace magazinn.Pages
{

    /// <summary>
    /// Логика взаимодействия для PageAddCompany.xaml
    /// </summary>
    public partial class PageAddCompany : Page
    {
        private Company _currentperson = new Company(); //экземпляр добавляемого пользователя
        public PageAddCompany(Company selectedCompany)
        {
            InitializeComponent();
            if (selectedCompany != null)
                _currentperson = selectedCompany;
            DataContext = _currentperson;
        }
        private void Savebtn_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();// Объект для сообщение об ошибке
            //проверка полей объекта
            if (string.IsNullOrWhiteSpace(_currentperson.CompanyName))
                error.AppendLine("Укажите название компании");
            if (string.IsNullOrWhiteSpace(_currentperson.Address))
                error.AppendLine("Укажите адрес");
            if (string.IsNullOrWhiteSpace(_currentperson.Telephone))
                error.AppendLine("Укажите номер телефона");
            if (error.Length > 0)

            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentperson.IDcompany == 0)
                MagazinEntities.GetContext().Company.Add(_currentperson);//Добавить в контекст
            try
            {

                MagazinEntities.GetContext().SaveChanges();// Сохранить изменения
                MessageBox.Show("Данные сохраненны");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }
    }
}
